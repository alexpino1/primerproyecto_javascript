
const elementos = ["Walter", 29,nacimiento,Desarrollador,libro];
Desarrollador=true;

if (true) {
    "soy un Desarrollador";
} 
else (false) 
    "no soy un desarrollador";
const nacimiento= new Date ("september 18 1993");

console.log(elementos)

const libro = {
    titulo: "ojos del perro siberiano ",
    autor: "ANTONIO SANTA ANA",
    fecha: new Date ("march 25 1998"),
    url: "https://www.alibrate.com/libro/los-o jos-del-perro-siberiano/59e1275e27c36459bb7aee96"
}

console.log(libro.titulo)



